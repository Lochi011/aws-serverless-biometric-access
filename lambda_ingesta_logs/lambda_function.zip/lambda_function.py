import json
import logging
from datetime import datetime
from db import get_db_connection

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    try:
        logger.info("Evento recibido: %s", json.dumps(
            event, ensure_ascii=False))

        # ──────────────────────────────
        # 1. Extraer campos
        # ──────────────────────────────
        payload = event                      # mensaje IoT Core
        uuid = payload["uuid"]
        raw_id = payload.get("access_user_id", "")      # puede venir ""
        device_name = payload["device_name"]
        event_type = payload["event"]
        timestamp = payload["timestamp"]

        # ──────────────────────────────
        # 2. Validaciones de formato
        # ──────────────────────────────
        if event_type not in ("accepted", "denied"):
            raise ValueError("event debe ser 'accepted' o 'denied'")

        # timestamp ISO-8601 (2025-..Z → +00:00)
        datetime.fromisoformat(timestamp.replace("Z", "+00:00"))

        # Convertir "UNKNOWN" en cadena vacía → luego se insertará NULL
        cedula = "" if raw_id.upper() == "UNKNOWN" else raw_id

        # ──────────────────────────────
        # 3. Preparar DB
        # ──────────────────────────────
        conn = get_db_connection()
        cur = conn.cursor()

        # UUID duplicado
        cur.execute("SELECT 1 FROM access_logs WHERE id = %s", (uuid,))
        if cur.fetchone():
            raise ValueError(f"Ya existe un log con UUID {uuid}")

        # ──────────────────────────────
        # 4. Resolver usuario
        # ──────────────────────────────
        access_user_id = None              # NULL por defecto

        if event_type == "accepted":
            # cédula obligatoria
            if not cedula:
                raise ValueError(
                    "El campo id/cedula no puede ser vacio en accepted")

            cur.execute(
                "SELECT id FROM access_users WHERE cedula = %s", (cedula,))
            row = cur.fetchone()
            if not row:
                raise ValueError(f"No existe usuario con cédula {cedula}")
            access_user_id = row[0]        # FK encontrada

        # (si 'denied' -> access_user_id permanece en None)

        # ──────────────────────────────
        # 5. Resolver dispositivo
        # ──────────────────────────────
        cur.execute("SELECT id_device FROM devices WHERE location = %s",
                    (device_name,))
        row = cur.fetchone()
        if not row:
            raise ValueError(f"No existe dispositivo '{device_name}'")
        device_id = row[0]

        # ──────────────────────────────
        # 6. Insertar log (access_user_id puede ser NULL)
        # ──────────────────────────────
        cur.execute("""
            INSERT INTO access_logs
                   (id, access_user_id, device_id, event, timestamp)
            VALUES (%s, %s, %s, %s, %s)
        """, (uuid, access_user_id, device_id, event_type, timestamp))

        conn.commit()
        cur.close()
        conn.close()

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Log insertado correctamente"})
        }

    except Exception as e:
        logger.error("Error procesando evento: %s", e)
        return {
            "statusCode": 400,
            "body": json.dumps({"error": str(e)})
        }
